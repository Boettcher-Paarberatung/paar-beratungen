<?php get_header();?>

<div class="container">
  <div class="row">
  
    <?php
      if ( function_exists('yoast_breadcrumb') ) {
        yoast_breadcrumb('<p id="breadcrumbs">','</p>');
      }
    ?>

    <?php if(have_posts()) : ?>

      <div class="col-md-12">
        <h1>Blog</h1>
        <p>Hier gibt es alle aktuellen Blogartikel</p>
      </div>
      <div class="col-md-9">  

        <?php while (have_posts()) : the_post();?>  
          <div class="col-md-12">
            <div class="col-md-3">
              <?php the_post_thumbnail('thumbnail'); ?>
            </div>
            <div class="col-md-9">
              <a href="<?php the_permalink(); ?>">
                <h4><?php the_title(); ?></h4>
              </a>
              <span><?php the_date(); ?></span>
              <span><?php the_author(); ?></span>
              <p><?php the_excerpt(); ?></p>  
            </div>
          </div>
        <?php endwhile; ?>

      </div>

    <?php endif; ?>

    <?php get_sidebar(); ?>

  </div>
</div>

<?php get_footer();?>