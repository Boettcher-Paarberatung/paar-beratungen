<div class="container-fluid">
	<div class="row" >
		<div class="frontpage-atf" style="background: url('<?php echo esc_url( get_theme_mod('frontpage_header_image')); ?>') no-repeat fixed center">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-9 col-xs-9">
			      <h1><?php echo get_theme_mod('frontpage_header_title'); ?></h1>
						<p><?php echo get_theme_mod('frontpage_header_subtitle'); ?></p>
			    </div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<?php echo do_shortcode('[webba_booking category="1" service="1"]'); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row frontpage-proof">
		<div class="container">
			<div class="col-md-12">
				<ul class="list-unstyled">
					<?php echo get_theme_mod('frontpage_header_list'); ?>
				</ul>
			</div>
		</div>
	</div>
</div>
