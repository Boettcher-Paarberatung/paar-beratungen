<div class="container-fluid">
	<div class="row">
		<a href="<?php echo get_page_link('854'); ?>" class="col-lg-12 col-md-12 col-sm-12 col-xs-12 btn btn-red"><?php echo get_theme_mod('frontpage_header_button_text'); ?></a>
	</div>
</div>
