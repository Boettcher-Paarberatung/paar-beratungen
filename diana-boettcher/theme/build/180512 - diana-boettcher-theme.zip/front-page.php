<?php get_header();?>

<div class="frontpage">
	
	<?php get_template_part('template-parts/frontpage/frontpage', 'header'); ?>	

	<?php get_template_part('template-parts/frontpage/frontpage', 'about_me'); ?>	

	<?php get_template_part('template-parts/frontpage/frontpage', 'forms'); ?>	

	<?php get_template_part('template-parts/frontpage/frontpage', 'first_talk'); ?>

	<?php get_template_part('template-parts/frontpage/frontpage', 'costs'); ?>

	<?php get_template_part('template-parts/modules/call_to_action'); ?>

	<?php get_template_part('template-parts/frontpage/frontpage', 'text'); ?>

	<?php get_template_part('template-parts/frontpage/frontpage', 'blog'); ?>

</div>

<?php get_footer();?>