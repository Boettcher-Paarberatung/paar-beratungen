		<?php get_template_part('template-parts/footer/footer', 'reviews'); ?>

		</div>

		<?php get_template_part('template-parts/footer/footer', 'map'); ?>

		<?php get_template_part('template-parts/modules/call_to_action'); ?>

		<?php dynamic_sidebar('footer-map'); ?>

		<?php get_template_part('template-parts/footer/footer', 'menu'); ?>

		<?php dynamic_sidebar('sticky'); ?>

		<?php wp_footer(); ?>

	</body>
</html>