<?php
/*
Template Name: Test
*/

echo phpinfo();


?>