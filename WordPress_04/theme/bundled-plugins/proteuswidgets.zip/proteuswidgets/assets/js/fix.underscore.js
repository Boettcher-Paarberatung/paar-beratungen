/**
 * UnderscoreJS module fix
 */
/*global define, _*/
define( [], function () {
	'use strict';
	return _;
} );