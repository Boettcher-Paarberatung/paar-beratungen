<?php
/**
 * Kingcomposer array
 *
 * @package Student WP
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

$orderby = array(
				"type"			=>	"select",
				"label"			=>	esc_html__("Order By", BUNCH_NAME),
				"name"			=>	"sort",
				'options'		=>	array('date'=>esc_html__('Date', BUNCH_NAME),'title'=>esc_html__('Title', BUNCH_NAME) ,'name'=>esc_html__('Name', BUNCH_NAME) ,'author'=>esc_html__('Author', BUNCH_NAME),'comment_count' =>esc_html__('Comment Count', BUNCH_NAME),'random' =>esc_html__('Random', BUNCH_NAME) ),
				"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
			);
$order = array(
				"type"			=>	"select",
				"label"			=>	esc_html__("Order", BUNCH_NAME),
				"name"			=>	"order",
				'options'		=>	(array('ASC'=>esc_html__('Ascending', BUNCH_NAME),'DESC'=>esc_html__('Descending', BUNCH_NAME) ) ),			
				"description"	=>	esc_html__("Enter the sorting order.", BUNCH_NAME)
			);
$number = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Number', BUNCH_NAME ),
				"name"			=>	"num",
				"description"	=>	esc_html__('Enter Number of posts to Show.', BUNCH_NAME )
			);
$text_limit = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Text Limit', BUNCH_NAME ),
				"name"			=>	"text_limit",
				"description"	=>	esc_html__('Enter text limit of posts to Show.', BUNCH_NAME )
			);
$title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"title",
				"description"	=>	esc_html__('Enter section title.', BUNCH_NAME )
			);
$heading = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Heading', BUNCH_NAME ),
				"name"			=>	"heading",
				"description"	=>	esc_html__('Enter Section Heading.', BUNCH_NAME )
			);
$subtitle = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Sub-Title', BUNCH_NAME ),
				"name"			=>	"subtitle",
				"description"	=>	esc_html__('Enter section subtitle.', BUNCH_NAME )
			);
$text  = array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Text', BUNCH_NAME ),
				"name"			=>	"text",
				"description"	=>	esc_html__('Enter text to show.', BUNCH_NAME )
			);
$btn_title = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Button Title', BUNCH_NAME ),
				"name"			=>	"btn_title",
				"description"	=>	esc_html__('Enter section Button title.', BUNCH_NAME )
			);
$btn_link = array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Button Link', BUNCH_NAME ),
				"name"			=>	"btn_link",
				"description"	=>	esc_html__('Enter section Button Link.', BUNCH_NAME )
			);
$bg_img = array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__('Background Image', BUNCH_NAME ),
				"name"			=>	"bg_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__('Choose Background image.', BUNCH_NAME )
			);

$options = array();


// Revslider Start.
$options['bunch_revslider']	=	array(
					'name' => esc_html__('Revslider', BUNCH_NAME),
					'base' => 'bunch_revslider',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show  Revolution slider.', BUNCH_NAME),
					'params' => array(
						array(
							'type' => 'dropdown',
							'label' => esc_html__('Choose Slider', BUNCH_NAME ),
							'name' => 'slider_slug',
							'options' => bunch_get_rev_slider( 0 ),
							'description' => esc_html__('Choose Slider', BUNCH_NAME )
						),

					),
			);

//Who We Are
$options['bunch_who_we_are']	=	array(
					'name' => esc_html__('Who We Are', BUNCH_NAME),
					'base' => 'bunch_who_we_are',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Who We Are Section', BUNCH_NAME),
					'params' => array(
                            $title,
							$heading,
							$text,
                            array(
                                "type"			=>	"textarea",
                                "label"			=>	esc_html__('Features', BUNCH_NAME ),
                                "name"			=>	"features",
                                "description"	=>	esc_html__('Enter features to show.', BUNCH_NAME )
                            ),
                            array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Upload Image', BUNCH_NAME ),
								"name"			=>	"attach_img",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose image.', BUNCH_NAME )
							),
							$btn_title,
							$btn_link,
					),
			);

//About Us
$options['bunch_about_us']	=	array(
					'name' => esc_html__('About Us', BUNCH_NAME),
					'base' => 'bunch_about_us',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show About Us Section', BUNCH_NAME),
					'params' => array(
                            array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Upload Image', BUNCH_NAME ),
								"name"			=>	"attach_img",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose image.', BUNCH_NAME )
							),
                            $title,
							$heading,
							$text,
                            array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Signature Image', BUNCH_NAME ),
								"name"			=>	"sign_img",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Signature image.', BUNCH_NAME )
							),
						),
			);


//Services Carousel
$options['bunch_services_carousel']	=	array(
					'name' => esc_html__('Services Carousel', BUNCH_NAME),
					'base' => 'bunch_services_carousel',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Grid Services.', BUNCH_NAME),
					'params' => array(
                        $title,
                        $text,
						$text_limit,
						$number,
						array(
							"type" => "dropdown",
							"label" => __( 'Category', BUNCH_NAME),
							"name" => "cat",
							"options" =>  bunch_get_categories(array( 'taxonomy' => 'services_category'), true),
							"description" => __( 'Choose Category.', BUNCH_NAME)
						),
						$orderby,
						$order,
                        array(
                            'name' => 'grey_bg',
                            'label' => __( 'Show Grey Background', BUNCH_NAME),
                            'type' => 'toggle',
                            'description' => __( 'Enable to Show Grey Background.', BUNCH_NAME)
                        ),
					),
			);


//Testimonials
$options['bunch_testimonials']	=	array(
					'name' => esc_html__('Our Testimonials', BUNCH_NAME),
					'base' => 'bunch_testimonials',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Testimonials.', BUNCH_NAME),
					'params' => array(
                        $bg_img,
                        $title,
                        $subtitle,
						$text_limit,
						$number,
						array(
							"type" => "dropdown",
							"label" => __( 'Category', BUNCH_NAME),
							"name" => "cat",
							"options" =>  bunch_get_categories(array( 'taxonomy' => 'testimonials_category'), true),
							"description" => __( 'Choose Category.', BUNCH_NAME)
						),
						$orderby,
						$order,

					),
			);


//fun Facts Home 1
$options['bunch_fun_facts']	=	array(
					'name' => esc_html__('Fun Facts', BUNCH_NAME),
					'base' => 'bunch_fun_facts',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Fun Facts.', BUNCH_NAME),
					'params' => array(
						//Group Start
							array(
								 'type' => 'group',
								 'label' => esc_html__( 'Fun Facts', BUNCH_NAME ),
								 'name' => 'facts',
								 'description' => esc_html__( 'Enter the Fun Facts.', BUNCH_NAME ),
								 'params' => array(
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Title', BUNCH_NAME ),
											 'name' => 'title',
											 'description' => esc_html__( 'Enter Facts title.', BUNCH_NAME ),
										),
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Data Speed', BUNCH_NAME ),
											 'name' => 'data_speed',
											 'description' => esc_html__( 'Enter Data Speed(e.g 2000 or 3000).', BUNCH_NAME ),
										),
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'End Number', BUNCH_NAME ),
											 'name' => 'end_num',
											 'description' => esc_html__( 'Enter End Number.', BUNCH_NAME ),
										),
								 ),
							),//Group End

					),
			);

//Why Choose US Home 1
$options['bunch_why_choose_us']	=	array(
					'name' => esc_html__('Why Choose Us', BUNCH_NAME),
					'base' => 'bunch_why_choose_us',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Why Choose Us.', BUNCH_NAME),
					'params' => array(
                        array(
                            "type"			=>	"attach_image_url",
                            "label"			=>	esc_html__('Upload Image', BUNCH_NAME ),
                            "name"			=>	"upload_img",
                            'admin_label' 	=> 	false,
                            "description"	=>	esc_html__('Upload image.', BUNCH_NAME )
                        ),
                        $title,
						//Group Start
							array(
								 'type' => 'group',
								 'label' => esc_html__( 'Add Group', BUNCH_NAME ),
								 'name' => 'choose_us',
								 'description' => esc_html__( 'Enter Group Items', BUNCH_NAME ),
								 'params' => array(
                                        array(
                                            'type' => 'icon_picker',
                                            'label' => esc_html__( 'Icon', BUNCH_NAME ),
                                            'name' => 'icons',
                                            'description' => esc_html__( 'Choose Icon.', BUNCH_NAME ),
                                       ),
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Title', BUNCH_NAME ),
											 'name' => 'title1',
											 'description' => esc_html__( 'Enter Facts title.', BUNCH_NAME ),
										),
										$text,
								 ),
							),//Group End
                            array(
                                'name' => 'remove_space',
                                'label' => __( 'Remove Top Extra Padding', BUNCH_NAME),
                                'type' => 'toggle',
                                'description' => __( 'Enable to Remove Top Extra Padding', BUNCH_NAME)
                            ),
					),
			);


//Our Blog Home 1
$options['bunch_our_blog']	=	array(
					'name' => esc_html__('Our Blog', BUNCH_NAME),
					'base' => 'bunch_our_blog',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Blog Home 1.', BUNCH_NAME),
					'params' => array(
						$title,
						$number,
						array(
							"type" => "dropdown",
							"label" => __('Category', BUNCH_NAME),
							"name" => "cat",
							"options" =>  bunch_get_categories(array('taxonomy' => 'category'), true),
							"description" => __('Choose Category.', BUNCH_NAME)
						),
						$orderby,
						$order,
                        array(
                            'name' => 'remove_space',
                            'label' => __( 'Remove Top Extra Padding', BUNCH_NAME),
                            'type' => 'toggle',
                            'description' => __( 'Enable to Remove Top Extra Padding', BUNCH_NAME)
                        ),
                        array(
                            'name' => 'add_top_space',
                            'label' => __( 'Add Top Padding', BUNCH_NAME),
                            'type' => 'toggle',
                            'description' => __( 'Enable to Add Top Padding', BUNCH_NAME)
                        ),
					),
			);

//Appointment Form
$options['bunch_appointment_form']	=	array(
					'name' => esc_html__('Appointment Form', BUNCH_NAME),
					'base' => 'bunch_appointment_form',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Appointment Form.', BUNCH_NAME),
					'params' => array(
                        $bg_img,
                        array(
                            "type"			=>	"textarea",
                            "label"			=>	esc_html__('Title', BUNCH_NAME ),
                            "name"			=>	"title",
                            "description"	=>	esc_html__('Enter title to show.', BUNCH_NAME )
                        ),
                        $text,
						array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Contact Form', BUNCH_NAME ),
							"name"			=>	"contact_form",
							"description"	=>	esc_html__('Enter Contact Form', BUNCH_NAME )
						),
					),
			);

//About Us Two
$options['bunch_about_us_two']	=	array(
					'name' => esc_html__('About Us Two', BUNCH_NAME),
					'base' => 'bunch_about_us_two',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show About Us Style Two Section', BUNCH_NAME),
					'params' => array(
                            $title,
                            $text,
                            $btn_title,
                            $btn_link,
                            array(
                                "type"			=>	"text",
                                "label"			=>	esc_html__('Phone Number', BUNCH_NAME ),
                                "name"			=>	"phone_num",
                                "description"	=>	esc_html__('Enter Phone Number to Show.', BUNCH_NAME )
                            ),
                            array(
                                "type"			=>	"text",
                                "label"			=>	esc_html__('Phone Number Two', BUNCH_NAME ),
                                "name"			=>	"phone_num2",
                                "description"	=>	esc_html__('Enter Phone Number Two to Show.', BUNCH_NAME )
                            ),
                            array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Video Image', BUNCH_NAME ),
								"name"			=>	"video_img",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Upload Video image.', BUNCH_NAME )
							),
                            array(
                                "type"			=>	"text",
                                "label"			=>	esc_html__('Video Link', BUNCH_NAME ),
                                "name"			=>	"video_link",
                                "description"	=>	esc_html__('Enter Video Link to Show.', BUNCH_NAME )
                            ),
						),
			);


//Why Choose US Two Home 2
$options['bunch_why_choose_us2']	=	array(
					'name' => esc_html__('Why Choose Us Two', BUNCH_NAME),
					'base' => 'bunch_why_choose_us2',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Why Choose Us Style Two.', BUNCH_NAME),
					'params' => array(
                        array(
                            "type"			=>	"attach_image_url",
                            "label"			=>	esc_html__('Upload Image', BUNCH_NAME ),
                            "name"			=>	"upload_img",
                            'admin_label' 	=> 	false,
                            "description"	=>	esc_html__('Upload image.', BUNCH_NAME )
                        ),
						//Group Start
							array(
								 'type' => 'group',
								 'label' => esc_html__( 'Add Group', BUNCH_NAME ),
								 'name' => 'choose_us',
								 'description' => esc_html__( 'Enter Group Items', BUNCH_NAME ),
								 'params' => array(
                                        array(
                                            'type' => 'icon_picker',
                                            'label' => esc_html__( 'Icon', BUNCH_NAME ),
                                            'name' => 'icons',
                                            'description' => esc_html__( 'Choose Icon.', BUNCH_NAME ),
                                       ),
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Title', BUNCH_NAME ),
											 'name' => 'title1',
											 'description' => esc_html__( 'Enter Facts title.', BUNCH_NAME ),
										),
										$text,
								 ),
							),//Group End

					),
			);

//Our Team
$options['bunch_our_team']	=	array(
					'name' => esc_html__('Our Team', BUNCH_NAME),
					'base' => 'bunch_our_team',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Team', BUNCH_NAME),
					'params' => array(
                        $title,
                        $text,
						$number,
						array(
							"type" => "dropdown",
							"label" => __( 'Category', BUNCH_NAME),
							"name" => "cat",
							"options" =>  bunch_get_categories(array( 'taxonomy' => 'team_category'), true),
							"description" => __( 'Choose Category.', BUNCH_NAME)
						),
						$orderby,
						$order,
                        array(
                            'name' => 'white_bg',
                            'label' => __( 'Show White Background', BUNCH_NAME),
                            'type' => 'toggle',
                            'description' => __( 'Enable to Show White Background', BUNCH_NAME)
                        ),
					),
			);

//google Map
$options['bunch_google_map']	=	array(
					'name' => esc_html__('Google Map', BUNCH_NAME),
					'base' => 'bunch_google_map',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show google Map.', BUNCH_NAME),
					'params' => array(
						array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Enter Latitude', BUNCH_NAME ),
							"name"			=>	"latitude",
							"description"	=>	esc_html__('Enter Latitude', BUNCH_NAME )
						),
						array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Enter Longitude', BUNCH_NAME ),
							"name"			=>	"longitude",
							"description"	=>	esc_html__('Enter Longitude', BUNCH_NAME )
						),
						array(
							"type"			=>	"attach_image_url",
							"label"			=>	esc_html__('Map Image', BUNCH_NAME ),
							"name"			=>	"map_img",
							'admin_label' 	=> 	false,
							"description"	=>	esc_html__('Upload Map Image.', BUNCH_NAME )
						),
                        array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Title', BUNCH_NAME ),
							"name"			=>	"map_title",
							"description"	=>	esc_html__('Enter Title', BUNCH_NAME )
						),
                        array(
							"type"			=>	"textarea",
							"label"			=>	esc_html__('Enter Address', BUNCH_NAME ),
							"name"			=>	"map_address",
							"description"	=>	esc_html__('Enter Address', BUNCH_NAME )
						),
                        array(
							"type"			=>	"text",
							"label"			=>	esc_html__('Enter Email', BUNCH_NAME ),
							"name"			=>	"map_email",
							"description"	=>	esc_html__('Enter Email ID', BUNCH_NAME )
						),
					),
			);

//About Us Three
$options['bunch_about_us_three']	=	array(
					'name' => esc_html__('About Us Style Three', BUNCH_NAME),
					'base' => 'bunch_about_us_three',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show About Us Style Three Section', BUNCH_NAME),
					'params' => array(
                            array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Upload Image', BUNCH_NAME ),
								"name"			=>	"attach_img",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose image.', BUNCH_NAME )
							),
                            $title,
							$heading,
							$text,
                            array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Signature Image', BUNCH_NAME ),
								"name"			=>	"sign_img",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Signature image.', BUNCH_NAME )
							),
						),
			);

//Psychology Clinic
$options['bunch_pychology_clinic']	=	array(
					'name' => esc_html__('Psychology Clinic', BUNCH_NAME),
					'base' => 'bunch_pychology_clinic',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Psychology Clinic Section', BUNCH_NAME),
					'params' => array(
							$title,
							$text,
                            array(
                                "type"			=>	"textarea",
                                "label"			=>	esc_html__('Features', BUNCH_NAME ),
                                "name"			=>	"features",
                                "description"	=>	esc_html__('Enter features to show.', BUNCH_NAME )
                            ),
					),
			);

//About Our Clinic
$options['bunch_about_our_clinic']	=	array(
					'name' => esc_html__('About Our Clinic', BUNCH_NAME),
					'base' => 'bunch_about_our_clinic',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Clinic Section', BUNCH_NAME),
					'params' => array(
                            array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Upload Image', BUNCH_NAME ),
								"name"			=>	"attach_img",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose image.', BUNCH_NAME )
							),
                            $title,
							$heading,
							$text,
                            $btn_title,
                            $btn_link,
						),
			);

//Our Approach
$options['bunch_our_approach']	=	array(
					'name' => esc_html__('Our Approach', BUNCH_NAME),
					'base' => 'bunch_our_approach',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Approach Section', BUNCH_NAME),
					'params' => array(
							$heading,
                            $title,
                            array(
                                "type"			=>	"textarea",
                                "label"			=>	esc_html__('Bold Text', BUNCH_NAME ),
                                "name"			=>	"bold_text",
                                "description"	=>	esc_html__('Enter Bold text to show.', BUNCH_NAME )
                            ),
							$text,
						),
			);

//About Me
$options['bunch_about_me']	=	array(
					'name' => esc_html__('About Me', BUNCH_NAME),
					'base' => 'bunch_about_me',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show About Me Section', BUNCH_NAME),
					'params' => array(
                        array(
                            "type"			=>	"attach_image_url",
                            "label"			=>	esc_html__('Upload Image', BUNCH_NAME ),
                            "name"			=>	"upload_img",
                            'admin_label' 	=> 	false,
                            "description"	=>	esc_html__('Upload image.', BUNCH_NAME )
                        ),
                        array(
                             'type' => 'text',
                             'label' => esc_html__( 'Phone Number', BUNCH_NAME ),
                             'name' => 'phone',
                             'description' => esc_html__( 'Enter Phone Number.', BUNCH_NAME ),
                        ),
                        array(
                             'type' => 'text',
                             'label' => esc_html__( 'Email ID', BUNCH_NAME ),
                             'name' => 'email',
                             'description' => esc_html__( 'Enter Email ID', BUNCH_NAME ),
                        ),
						//Group Start
							array(
								 'type' => 'group',
								 'label' => esc_html__( 'Social Media', BUNCH_NAME ),
								 'name' => 'social_media',
								 'description' => esc_html__( 'Enter Social Media', BUNCH_NAME ),
								 'params' => array(
                                        array(
                                            'type' => 'icon_picker',
                                            'label' => esc_html__( 'Icon', BUNCH_NAME ),
                                            'name' => 'icons',
                                            'description' => esc_html__( 'Choose Icon.', BUNCH_NAME ),
                                       ),
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Permalink', BUNCH_NAME ),
											 'name' => 'permalink',
											 'description' => esc_html__( 'Enter Permalink', BUNCH_NAME ),
										),
								 ),
							),//Group End
                            $title,
                            array(
                                 'type' => 'text',
                                 'label' => esc_html__( 'Designation', BUNCH_NAME ),
                                 'name' => 'designation',
                                 'description' => esc_html__( 'Enter Designation', BUNCH_NAME ),
                            ),
                            $text,
                            $heading,
                            array(
                                "type"			=>	"textarea",
                                "label"			=>	esc_html__('Enter Content', BUNCH_NAME ),
                                "name"			=>	"content",
                                "description"	=>	esc_html__('Enter Content to show.', BUNCH_NAME )
                            ),
                            array(
                                "type"			=>	"attach_image_url",
                                "label"			=>	esc_html__('Signature Image', BUNCH_NAME ),
                                "name"			=>	"sign_img",
                                'admin_label' 	=> 	false,
                                "description"	=>	esc_html__('Upload Signature image.', BUNCH_NAME )
                            ),
					),
			);

//Professional Education
$options['bunch_professional_education']	=	array(
					'name' => esc_html__('Professional Education', BUNCH_NAME),
					'base' => 'bunch_professional_education',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Professional Education', BUNCH_NAME),
					'params' => array(
                            $title,
						    //Group Start
							array(
								 'type' => 'group',
								 'label' => esc_html__( 'Add Educational Info', BUNCH_NAME ),
								 'name' => 'edu_info',
								 'description' => esc_html__( 'Enter Educational Info.', BUNCH_NAME ),
								 'params' => array(
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Year', BUNCH_NAME ),
											 'name' => 'year',
											 'description' => esc_html__( 'Enter Year', BUNCH_NAME ),
										),
										array(
											 'type' => 'text',
											 'label' => esc_html__( 'Title', BUNCH_NAME ),
											 'name' => 'title1',
											 'description' => esc_html__( 'Enter Title', BUNCH_NAME ),
										),
										$text
								 ),
							),//Group End

					),
			);

//Our Faqs
$options['bunch_our_faqs']	=	array(
					'name' => esc_html__('Our Faqs', BUNCH_NAME),
					'base' => 'bunch_our_faqs',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Faqs.', BUNCH_NAME),
					'params' => array(
						$title,
                        $subtitle,
						$number,
                        $text_limit,
						array(
							"type" => "dropdown",
							"label" => __('Category', BUNCH_NAME),
							"name" => "cat",
							"options" =>  bunch_get_categories(array('taxonomy' => 'faqs_category'), true),
							"description" => __('Choose Category.', BUNCH_NAME)
						),
						$orderby,
						$order,
                        array(
                            'name' => 'hide_search',
                            'label' => __( 'Hide Search Area', BUNCH_NAME),
                            'type' => 'toggle',
                            'description' => __( 'Enable to Hide Search Area', BUNCH_NAME)
                        ),
					),
			);

//Contact Form
$options['bunch_faq_form']	=	array(
					'name' => esc_html__('Faqs Form', BUNCH_NAME),
					'base' => 'bunch_faq_form',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Faqs Form', BUNCH_NAME),
					'params' => array(
                        $title,
                        array(
                            "type"			=>	"textarea",
                            "label"			=>	esc_html__('Contact Form', BUNCH_NAME ),
                            "name"			=>	"faq_form",
                            "description"	=>	esc_html__('Enter Contact Form', BUNCH_NAME )
                        ),
					),
			);

//Our Services
$options['bunch_our_services']	=	array(
					'name' => esc_html__('Our Services', BUNCH_NAME),
					'base' => 'bunch_our_services',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Services.', BUNCH_NAME),
					'params' => array(
                        $title,
                        $text,
						$text_limit,
						$number,
						array(
							"type" => "dropdown",
							"label" => __( 'Category', BUNCH_NAME),
							"name" => "cat",
							"options" =>  bunch_get_categories(array( 'taxonomy' => 'services_category'), true),
							"description" => __( 'Choose Category.', BUNCH_NAME)
						),
						$orderby,
						$order,
					),
			);

//Services Single
$options['bunch_services_single']	=	array(
	'name' => esc_html__( 'Services Single', BUNCH_NAME ),
	'base' => 'bunch_services_single',
	'class' => '',
	'category' => esc_html__( 'Mindron', BUNCH_NAME ),
	'icon' => 'fa-briefcase' ,
	'description' => esc_html__( 'Show Services Detail Page', BUNCH_NAME ),
	'params' => array(
		esc_html__( 'Sidebar', BUNCH_NAME ) => array(
			array(
				   'type' => 'dropdown',
				   'label' => esc_html__( 'Choose Sidebar', BUNCH_NAME ),
				   'name' => 'sidebar_slug',
				   'options' => mindron_bunch_get_sidebars(),
				   'description' => esc_html__( 'Choose Sidebar.', BUNCH_NAME ),
			),
		),
		esc_html__( 'Therapy', BUNCH_NAME ) => array(
			array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__( 'Upload Image', BUNCH_NAME ),
				"name"			=>	"therapy_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__( 'Upload image.', BUNCH_NAME )
			),
			array(
				"type"			=>	"text",
				"label"			=>	esc_html__( 'Title', BUNCH_NAME ),
				"name"			=>	"therapy_title",
				"description"	=>	esc_html__( 'Enter Title.', BUNCH_NAME )
			),
			$text,
		),
        esc_html__( 'Benefits', BUNCH_NAME ) => array(
			array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__( 'Upload Image', BUNCH_NAME ),
				"name"			=>	"benefits_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__( 'Upload image.', BUNCH_NAME )
			),
			array(
				"type"			=>	"text",
				"label"			=>	esc_html__( 'Title', BUNCH_NAME ),
				"name"			=>	"benefits_title",
				"description"	=>	esc_html__( 'Enter Title.', BUNCH_NAME )
			),
            array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__( 'Text', BUNCH_NAME ),
				"name"			=>	"benefits_text",
				"description"	=>	esc_html__( 'Enter Text.', BUNCH_NAME )
			),
            array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Features', BUNCH_NAME ),
				"name"			=>	"benefits_features",
				"description"	=>	esc_html__('Enter Features.', BUNCH_NAME )
			),
		),
		esc_html__( 'Services', BUNCH_NAME ) => array(
			array(
                 'type' => 'group',
                 'label' => esc_html__( 'Add Services', BUNCH_NAME ),
                 'name' => 'add_services',
                 'description' => esc_html__( 'Enter Services', BUNCH_NAME ),
                 'params' => array(
                        array(
                            'type' => 'icon_picker',
                            'label' => esc_html__( 'Icon', BUNCH_NAME ),
                            'name' => 'services_icon',
                            'description' => esc_html__( 'Choose Icon.', BUNCH_NAME ),
                       ),
                       array(
                            "type"			=>	"text",
                            "label"			=>	esc_html__( 'Title', BUNCH_NAME ),
                            "name"			=>	"services_title",
                            "description"	=>	esc_html__( 'Enter Title.', BUNCH_NAME )
                        ),
                        array(
                            "type"			=>	"text",
                            "label"			=>	esc_html__( 'Link', BUNCH_NAME ),
                            "name"			=>	"services_link",
                            "description"	=>	esc_html__( 'Enter Permalink.', BUNCH_NAME )
                        ),
                        array(
                             'type' => 'textarea',
                             'label' => esc_html__( 'Text', BUNCH_NAME ),
                             'name' => 'services_text',
                             'description' => esc_html__( 'Enter Text', BUNCH_NAME ),
                        ),
                 ),
            ),//Group End
		),
        esc_html__( 'Why Choose US', BUNCH_NAME ) => array(
			array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"choose_title",
				"description"	=>	esc_html__('Enter Title.', BUNCH_NAME )
			),
			array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Text', BUNCH_NAME ),
				"name"			=>	"choose_text",
				"description"	=>	esc_html__('Enter Text.', BUNCH_NAME )
			),
			array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Features', BUNCH_NAME ),
				"name"			=>	"choose_features",
				"description"	=>	esc_html__('Enter Features.', BUNCH_NAME )
			),
		),
	),
);

//Services Single Style Two
$options['bunch_services_single_two']	=	array(
	'name' => esc_html__( 'Services Single Style Two', BUNCH_NAME ),
	'base' => 'bunch_services_single_two',
	'class' => '',
	'category' => esc_html__( 'Mindron', BUNCH_NAME ),
	'icon' => 'fa-briefcase' ,
	'description' => esc_html__( 'Show Services Detail Page Style Two', BUNCH_NAME ),
	'params' => array(
		esc_html__( 'Sidebar', BUNCH_NAME ) => array(
			array(
				   'type' => 'dropdown',
				   'label' => esc_html__( 'Choose Sidebar', BUNCH_NAME ),
				   'name' => 'sidebar_slug',
				   'options' => mindron_bunch_get_sidebars(),
				   'description' => esc_html__( 'Choose Sidebar.', BUNCH_NAME ),
			),
		),
		esc_html__( 'Therapy', BUNCH_NAME ) => array(
			array(
				"type"			=>	"attach_images",
				"label"			=>	esc_html__( 'Upload Image', BUNCH_NAME ),
				"name"			=>	"therapy_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__( 'Upload image.', BUNCH_NAME )
			),
			array(
				"type"			=>	"text",
				"label"			=>	esc_html__( 'Title', BUNCH_NAME ),
				"name"			=>	"therapy_title",
				"description"	=>	esc_html__( 'Enter Title.', BUNCH_NAME )
			),
			$text,
		),
        esc_html__( 'Benefits', BUNCH_NAME ) => array(
			array(
				"type"			=>	"attach_image_url",
				"label"			=>	esc_html__( 'Upload Image', BUNCH_NAME ),
				"name"			=>	"benefits_img",
				'admin_label' 	=> 	false,
				"description"	=>	esc_html__( 'Upload image.', BUNCH_NAME )
			),
			array(
				"type"			=>	"text",
				"label"			=>	esc_html__( 'Title', BUNCH_NAME ),
				"name"			=>	"benefits_title",
				"description"	=>	esc_html__( 'Enter Title.', BUNCH_NAME )
			),
            array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__( 'Text', BUNCH_NAME ),
				"name"			=>	"benefits_text",
				"description"	=>	esc_html__( 'Enter Text.', BUNCH_NAME )
			),
            array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Features', BUNCH_NAME ),
				"name"			=>	"benefits_features",
				"description"	=>	esc_html__('Enter Features.', BUNCH_NAME )
			),
		),
		esc_html__( 'Services', BUNCH_NAME ) => array(
			array(
                 'type' => 'group',
                 'label' => esc_html__( 'Add Services', BUNCH_NAME ),
                 'name' => 'add_services',
                 'description' => esc_html__( 'Enter Services', BUNCH_NAME ),
                 'params' => array(
                        array(
                            'type' => 'icon_picker',
                            'label' => esc_html__( 'Icon', BUNCH_NAME ),
                            'name' => 'services_icon',
                            'description' => esc_html__( 'Choose Icon.', BUNCH_NAME ),
                       ),
                       array(
                            "type"			=>	"text",
                            "label"			=>	esc_html__( 'Title', BUNCH_NAME ),
                            "name"			=>	"services_title",
                            "description"	=>	esc_html__( 'Enter Title.', BUNCH_NAME )
                        ),
                        array(
                            "type"			=>	"text",
                            "label"			=>	esc_html__( 'Link', BUNCH_NAME ),
                            "name"			=>	"services_link",
                            "description"	=>	esc_html__( 'Enter Permalink.', BUNCH_NAME )
                        ),
                        array(
                             'type' => 'textarea',
                             'label' => esc_html__( 'Text', BUNCH_NAME ),
                             'name' => 'services_text',
                             'description' => esc_html__( 'Enter Text', BUNCH_NAME ),
                        ),
                 ),
            ),//Group End
		),
        esc_html__( 'Why Choose US', BUNCH_NAME ) => array(
			array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"choose_title",
				"description"	=>	esc_html__('Enter Title.', BUNCH_NAME )
			),
			array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Text', BUNCH_NAME ),
				"name"			=>	"choose_text",
				"description"	=>	esc_html__('Enter Text.', BUNCH_NAME )
			),
			array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Features', BUNCH_NAME ),
				"name"			=>	"choose_features",
				"description"	=>	esc_html__('Enter Features.', BUNCH_NAME )
			),
		),
        esc_html__( 'Consultation', BUNCH_NAME ) => array(
			array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Title', BUNCH_NAME ),
				"name"			=>	"consult_title",
				"description"	=>	esc_html__('Enter Title.', BUNCH_NAME )
			),
			array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Consultation Form', BUNCH_NAME ),
				"name"			=>	"consult_form",
				"description"	=>	esc_html__('Enter Consultation Form Code.', BUNCH_NAME )
			),
		),
	),
);

//Contact Info & Contact Form
$options['bunch_contact_form']	=	array(
	'name' => esc_html__( 'Contact Form', BUNCH_NAME ),
	'base' => 'bunch_contact_form',
	'class' => '',
	'category' => esc_html__( 'Mindron', BUNCH_NAME ),
	'icon' => 'fa-briefcase' ,
	'description' => esc_html__( 'Show Contact Form & Contact Info section', BUNCH_NAME ),
	'params' => array(
		esc_html__( 'General', BUNCH_NAME ) => array(
			$title,
			$text,
		),
        esc_html__( 'Contact Form', BUNCH_NAME ) => array(
			array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Contact Form', BUNCH_NAME ),
				"name"			=>	"contact_form",
				"description"	=>	esc_html__('Enter Contact Form.', BUNCH_NAME )
			),
		),
		esc_html__( 'Contatc Info', BUNCH_NAME ) => array(
			array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Address', BUNCH_NAME ),
				"name"			=>	"office_address",
				"description"	=>	esc_html__('Enter Address.', BUNCH_NAME )
			),
			array(
				"type"			=>	"textarea",
				"label"			=>	esc_html__('Phone Numbers', BUNCH_NAME ),
				"name"			=>	"office_phone",
				"description"	=>	esc_html__('Enter Phone Numbers.', BUNCH_NAME )
			),
			array(
				"type"			=>	"text",
				"label"			=>	esc_html__('Email ID', BUNCH_NAME ),
				"name"			=>	"office_email",
				"description"	=>	esc_html__('Enter Email ID.', BUNCH_NAME )
			),
		),
	),
);

//Our Gallery
$options['bunch_our_gallery']	=	array(
					'name' => esc_html__('Our Gallery', BUNCH_NAME),
					'base' => 'bunch_our_gallery',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Gallery.', BUNCH_NAME),
					'params' => array(
						$number,
						array(
							"type" => "dropdown",
							"label" => __('Category', BUNCH_NAME),
							"name" => "cat",
							"options" =>  bunch_get_categories(array('taxonomy' => 'gallery_category'), true),
							"description" => __('Choose Category.', BUNCH_NAME)
						),
						$orderby,
						$order
					),
			);

//Our Testimonials
$options['bunch_our_testimonials']	=	array(
					'name' => esc_html__('Our Testimonials Style Two', BUNCH_NAME),
					'base' => 'bunch_our_testimonials',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Our Testimonials Style Two.', BUNCH_NAME),
					'params' => array(
                        $title,
                        $subtitle,
						$text_limit,
						$number,
						array(
							"type" => "dropdown",
							"label" => __( 'Category', BUNCH_NAME),
							"name" => "cat",
							"options" =>  bunch_get_categories(array( 'taxonomy' => 'testimonials_category'), true),
							"description" => __( 'Choose Category.', BUNCH_NAME)
						),
						$orderby,
						$order,
					),
			);

//Blog Grid
$options['bunch_blog_grid']	=	array(
					'name' => esc_html__('Blog Grid', BUNCH_NAME),
					'base' => 'bunch_blog_grid',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Blog Grid.', BUNCH_NAME),
					'params' => array(
						$number,
                        $text_limit,
						array(
							"type" => "dropdown",
							"label" => __('Category', BUNCH_NAME),
							"name" => "cat",
							"options" =>  bunch_get_categories(array('taxonomy' => 'category'), true),
							"description" => __('Choose Category.', BUNCH_NAME)
						),
						$orderby,
						$order
					),
			);

//Patients Paper Work
$options['bunch_patient_paperwork']	=	array(
					'name' => esc_html__('Patient Paper Work', BUNCH_NAME),
					'base' => 'bunch_patient_paperwork',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Patient Paper Work Section.', BUNCH_NAME),
					'params' => array(
                        esc_html__( 'Offer', BUNCH_NAME ) => array(
                            //Group Start
                                array(
                                     'type' => 'textarea',
                                     'label' => esc_html__( 'Title', BUNCH_NAME ),
                                     'name' => 'offer_title',
                                     'description' => esc_html__( 'Enter Title.', BUNCH_NAME ),
                                ),
                                array(
                                     'type' => 'textarea',
                                     'label' => esc_html__( 'Text', BUNCH_NAME ),
                                     'name' => 'offer_text',
                                     'description' => esc_html__( 'Enter Text.', BUNCH_NAME ),
                                ),
                                $btn_title,
                                $btn_link,
                            ),
                            esc_html__( 'General', BUNCH_NAME ) => array(
                                $title,
                                $subtitle,
                                $text,
                                array(
                                     'type' => 'textarea',
                                     'label' => esc_html__( 'Features', BUNCH_NAME ),
                                     'name' => 'features',
                                     'description' => esc_html__( 'Enter Features.', BUNCH_NAME ),
                                ),
                                array(
                                     'type' => 'group',
                                     'label' => esc_html__( 'Add Buttons', BUNCH_NAME ),
                                     'name' => 'add_btns',
                                     'description' => esc_html__( 'Add Buttons', BUNCH_NAME ),
                                     'params' => array(
                                            array(
                                                 'type' => 'text',
                                                 'label' => esc_html__( 'Button Title', BUNCH_NAME ),
                                                 'name' => 'button_title',
                                                 'description' => esc_html__( 'Enter Button title.', BUNCH_NAME ),
                                            ),
                                            array(
                                                 'type' => 'text',
                                                 'label' => esc_html__( 'Add Permalink', BUNCH_NAME ),
                                                 'name' => 'button_link',
                                                 'description' => esc_html__( 'Enter Permalink.', BUNCH_NAME ),
                                            ),
                                     ),
                                ),//Group End
                            ),
					),
			);

//Consultation Form
$options['bunch_consult_form']	=	array(
					'name' => esc_html__('Consultation Form', BUNCH_NAME),
					'base' => 'bunch_consult_form',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Consultation Form', BUNCH_NAME),
					'params' => array(
                        $title,
                        $subtitle,
                        array(
                            "type"			=>	"textarea",
                            "label"			=>	esc_html__('Contact Form', BUNCH_NAME ),
                            "name"			=>	"consult_form",
                            "description"	=>	esc_html__('Enter Contact Form', BUNCH_NAME )
                        ),
					),
			);

//Visit Experience
$options['bunch_visit_experience']	=	array(
					'name' => esc_html__('Visit Experience', BUNCH_NAME),
					'base' => 'bunch_visit_experience',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show Visit Experience Section.', BUNCH_NAME),
					'params' => array(
                        esc_html__( 'Offer', BUNCH_NAME ) => array(
                            //Group Start
                                array(
                                     'type' => 'textarea',
                                     'label' => esc_html__( 'Title', BUNCH_NAME ),
                                     'name' => 'offer_title',
                                     'description' => esc_html__( 'Enter Title.', BUNCH_NAME ),
                                ),
                                array(
                                     'type' => 'textarea',
                                     'label' => esc_html__( 'Text', BUNCH_NAME ),
                                     'name' => 'offer_text',
                                     'description' => esc_html__( 'Enter Text.', BUNCH_NAME ),
                                ),
                                $btn_title,
                                $btn_link,
                            ),
                            esc_html__( 'General', BUNCH_NAME ) => array(
                                array(
                                    "type"			=>	"attach_image_url",
                                    "label"			=>	esc_html__('Upload Image', BUNCH_NAME ),
                                    "name"			=>	"upload_img",
                                    'admin_label' 	=> 	false,
                                    "description"	=>	esc_html__('Upload image.', BUNCH_NAME )
                                ),
                                $title,
                                array(
                                     'type' => 'group',
                                     'label' => esc_html__( 'Add Group', BUNCH_NAME ),
                                     'name' => 'add_group',
                                     'description' => esc_html__( 'Add Group', BUNCH_NAME ),
                                     'params' => array(
                                            array(
                                                 'type' => 'text',
                                                 'label' => esc_html__( 'Button Title', BUNCH_NAME ),
                                                 'name' => 'group_title',
                                                 'description' => esc_html__( 'Enter Title.', BUNCH_NAME ),
                                            ),
                                            array(
                                                 'type' => 'textarea',
                                                 'label' => esc_html__( 'Text', BUNCH_NAME ),
                                                 'name' => 'group_text',
                                                 'description' => esc_html__( 'Enter Text', BUNCH_NAME ),
                                            ),
                                     ),
                                ),//Group End
                            ),
					),
			);

//About Us
$options['bunch_about_us2']	=	array(
					'name' => esc_html__('About Us Style Two', BUNCH_NAME),
					'base' => 'bunch_about_us2',
					'class' => '',
					'category' => esc_html__('Mindron', BUNCH_NAME),
					'icon' => 'fa-briefcase' ,
					'description' => esc_html__('Show About Us Style Two Section', BUNCH_NAME),
					'params' => array(
                            array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Upload Image', BUNCH_NAME ),
								"name"			=>	"attach_img",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose image.', BUNCH_NAME )
							),
                            $title,
							$heading,
							$text,
                            array(
								"type"			=>	"attach_image_url",
								"label"			=>	esc_html__('Signature Image', BUNCH_NAME ),
								"name"			=>	"sign_img",
								'admin_label' 	=> 	false,
								"description"	=>	esc_html__('Choose Signature image.', BUNCH_NAME )
							),
						),
			);

return $options;