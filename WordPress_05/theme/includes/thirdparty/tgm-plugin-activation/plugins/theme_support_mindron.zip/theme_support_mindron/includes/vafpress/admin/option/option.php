<?php
return array(
    'title' => __( 'Mindron Theme Options', BUNCH_NAME ),
    'logo' => get_template_directory_uri() . '/images/logo.png',
    'menus' => array(
         // General Settings
         array(
            'title' => __( 'General Settings', BUNCH_NAME ),
            'name' => 'general_settings',
            'icon' => 'font-awesome:fa fa-cogs',
            'menus' => array(
                // general sub settings
				array(
                    'title' => __( 'general Settings', BUNCH_NAME ),
                    'name' => 'general_sub_settings',
                    'icon' => 'font-awesome:fa fa-dashboard',
                    'controls' => array(
                        array(
                            'type' => 'toggle',
                            'name' => 'preloader',
                            'label' => __( 'Preloader', BUNCH_NAME ),
							'default' => 0,
							'description' => __('show or hide Preloader', BUNCH_NAME)
						),
					) 
                    
                ),
				// api key settings
				array(
                    'title' => __( 'API Keys Settings', BUNCH_NAME ),
                    'name' => 'api_key_settings',
                    'icon' => 'font-awesome:fa fa-key',
                    'controls' => array(
                        array(
							'type' => 'textbox',
							'name' => 'map_api_key',
							'label' => __( 'Map Api Key', BUNCH_NAME ),
							'default' => '',
							'description' => __('Enter the map Api key', BUNCH_NAME)
						),
					) 
                    
                ),
			) 
         ),
		 // Skin settings
 		/* array(
			'title' => __( 'Skin Settings', BUNCH_NAME ),
			'name' => 'skin_settings',
			'icon' => 'font-awesome:fa-paint-brush',
			'controls' => array(
				// predefined color settings
				array(
					'type' => 'section',
					'repeating' => true,
					'sortable' => true,
					'title' => __( 'Predefined Color Schemes', BUNCH_NAME ),
					'name' => 'predefined_colors_schemes',
					'description' => __( 'This section is used for theme color settings', BUNCH_NAME ),
					'fields' => array(
						 array(
							'type' => 'radioimage',
							'name' => 'predefined_color_scheme',
							'label' => __( 'Predefined Colors', BUNCH_NAME ),
							'description' => __( 'Choose the Predefined color scheme', BUNCH_NAME ),
							'items' => array(
								array(
									'value' => 'pink',
									'label' => __( 'Pink', BUNCH_NAME ),
									'img' => get_template_directory_uri().'/images/vafpress/colors/pink.png' 
								),
								array(
									'value' => 'green',
									'label' => __( 'Green', BUNCH_NAME ),
									'img' => get_template_directory_uri().'/images/vafpress/colors/green.png' 
								),
								array(
									'value' => 'chocolate',
									'label' => __( 'Chocolate', BUNCH_NAME ),
									'img' => get_template_directory_uri().'/images/vafpress/colors/chocolate.png' 
								),
								array(
									'value' => 'purple',
									'label' => __( 'Purple', BUNCH_NAME ),
									'img' => get_template_directory_uri().'/images/vafpress/colors/purple.png' 
								),
								array(
									'value' => 'yellow',
									'label' => __( 'Yellow', BUNCH_NAME ),
									'img' => get_template_directory_uri().'/images/vafpress/colors/yellow.png' 
								),
								array(
									'value' => 'seagreen',
									'label' => __( 'Seagreen', BUNCH_NAME ),
									'img' => get_template_directory_uri().'/images/vafpress/colors/seagreen.png' 
								),
								
							) 
						),  
					)
				),
				// custom color settings
				array(
					'type' => 'section',
					'repeating' => true,
					'sortable' => true,
					'title' => __( 'Custom Color Scheme', BUNCH_NAME ),
					'name' => 'color_schemes',
					'description' => __( 'This section is used for theme color settings', BUNCH_NAME ),
					'fields' => array(
						array(
							'type' => 'color',
							'name' => 'main_color_scheme',
							'label' => __( 'Main Custom Color Scheme', BUNCH_NAME ),
							'description' => __( 'Choose the Custom color scheme for the theme.', BUNCH_NAME ),
							'default' => '#ab7442',
						),
					)
				),
			) 
		 ),*/
		 // Header Settings
         array(
            'title' => __( 'Header Settings', BUNCH_NAME ),
            'name' => 'header_settings',
            'icon' => 'font-awesome:fa fa-cube',
            'menus' => array(
				//logo settings
                array(
                    'title' => __( 'Logo Settings', BUNCH_NAME ),
                    'name' => 'logo_settings',
                    'icon' => 'font-awesome:fa fa-cube',
                    'controls' => array(
                        array(
                             'type' => 'upload',
                            'name' => 'site_favicon',
                            'label' => __( 'Favicon', BUNCH_NAME ),
                            'description' => __( 'Upload the favicon, should be 16x16', BUNCH_NAME ),
                            'default' => get_template_directory_uri().'/images/favicon.png'
                        ),
						array(
                            'type' => 'section',
                            'repeating' => true,
                            'sortable' => true,
                            'title' => __( 'Logo Sub Settings', BUNCH_NAME ),
                            'name' => 'logo_sub_settings',
                            'description' => __( 'This section is used for logo sub settings', BUNCH_NAME ),
                            'fields' => array(
                                array(
									'type' => 'upload',
									'name' => 'logo_image',
									'label' => __('Logo Image', BUNCH_NAME),
									'description' => __('Insert the logo image', BUNCH_NAME),
									'default' => get_template_directory_uri().'/images/logo.png'
								),
							)
						),
					) 
                ),
				//header sub settings
				array(
                    'title' => __( 'Header Settings', BUNCH_NAME ),
                    'name' => 'header_sub_settings',
                    'icon' => 'font-awesome:fa fa-cube',
                    'controls' => array(
                         array(
                            'type' => 'toggle',
                            'name' => 'header_top',
                            'label' => __( 'Show Header Top', BUNCH_NAME ),
                            'default' => 0,
                            'description' => __('show or hide Header Top', BUNCH_NAME)

                         ),
						 array(
							'type' => 'textbox',
							'name' => 'header_phone',
							'label' => __( 'Phone Number', BUNCH_NAME ),
							'default' => '1800.879.5247',
							'description' => __( 'Enter Phone Number', BUNCH_NAME )
						),
                        array(
							'type' => 'textbox',
							'name' => 'header_email',
							'label' => __( 'Email ID', BUNCH_NAME ),
							'default' => 'contact@mindron.com',
							'description' => __('Enter Email ID', BUNCH_NAME)
						),
                        array(
							'type' => 'textbox',
							'name' => 'appointment_link',
							'label' => __( 'Appointment Button Link', BUNCH_NAME ),
							'default' => '#',
							'description' => __( 'Enter Appointment Button Link', BUNCH_NAME )
						),
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_search',
                            'label' => __( 'Hide Search Area', BUNCH_NAME ),
                            'default' => 0,
                            'description' => __('show or hide Search Area', BUNCH_NAME)

                        ),
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_appoint_btn',
                            'label' => __( 'Hide Appointment Button', BUNCH_NAME ),
                            'default' => 0,
                            'description' => __('show or hide Appointment Button', BUNCH_NAME)

                        ),
                         array(
							'type' => 'radioimage',
							'name' => 'header_style',
							'label' => __( 'Choose Header Style', BUNCH_NAME ),
							'item_max_height' => '200',
							'item_max_width' => '700',
							'items' => array(
								 array(
									'value' => 'defaul_header',
									'label' => __( 'Default Header', BUNCH_NAME ),
									'img' => get_template_directory_uri() . '/images/vafpress/header/header1.png' 
								),
								array(
									'value' => 'header_style_one',
									'label' => __( 'Header Style One', BUNCH_NAME ),
									'img' => get_template_directory_uri() . '/images/vafpress/header/header2.png' 
								),
								array(
									'value' => 'header_style_two',
									'label' => __( 'Header Style Two', BUNCH_NAME ),
									'img' => get_template_directory_uri() . '/images/vafpress/header/header3.png' 
								),
								
							),
							'default' => 'defaul_header'
						),
					) 
                    
                ),
			) 
        ),
		 // Footer Settings
		 array(
			'title' => __( 'Footer Settings', BUNCH_NAME ),
			'name' => 'sub_footer_settings',
			'icon' => 'font-awesome:fa fa-edit',
			'controls' => array(
				array(
					'type' => 'toggle',
					'name' => 'hide_whole_footer',
					'label' => __( 'Hide Whole Footer', BUNCH_NAME ),
					'default' => 0,
					'description' => __('show or hide Whole footer', BUNCH_NAME)
				),
				array(
					'type' => 'toggle',
					'name' => 'hide_upper_footer',
					'label' => __( 'Hide Upper Footer', BUNCH_NAME ),
					'default' => 0,
					'description' => __('show or hide Upper footer', BUNCH_NAME)
				),
				array(
					'type' => 'toggle',
					'name' => 'hide_footer_copyright',
					'label' => __( 'Hide Copyright', BUNCH_NAME ),
					'default' => 0,
					'description' => __('show or hide Copyright footer', BUNCH_NAME)
				),
				//footer other settings
				array(
					'type' => 'section',
					'repeating' => true,
					'sortable' => true,
					'title' => __( 'Footer Other Settings', BUNCH_NAME ),
					'name' => 'footer_other_settings',
					'description' => __( 'This section is used for the footer settings', BUNCH_NAME ),
					'fields' => array(
						array(
							'type' => 'textarea',
							'name' => 'footer_copyright',
							'label' => __( 'Copyright', BUNCH_NAME ),
							'description' => __( 'Enter Copyright', BUNCH_NAME ),
							'default' => '&copy; Copyright  Mindron 2018. All right reserved.'
						),
						array(
							'type' => 'textbox',
							'name' => 'created_by',
							'label' => __( 'Author Name', BUNCH_NAME ),
							'description' => __( 'Enter Name (Created By)', BUNCH_NAME ),
							'default' => 'Created by Themearc'
						),
                        array(
                            'type' => 'toggle',
                            'name' => 'hide_go_to_top',
                            'label' => __( 'Hide Go To Top Button', BUNCH_NAME ),
                            'default' => 0,
                            'description' => __('show or hide Go To Top Button footer', BUNCH_NAME)

                        ),
					)
				),
			) 
		), 
         // Clients Settings
        /* array(
            'title' => __( 'Clients', BUNCH_NAME ),
            'name' => 'clients',
            'icon' => 'font-awesome:fa fa-share-square',
            'controls' => array(
                 array(
                     'type' => 'builder',
                    'repeating' => true,
                    'sortable' => true,
                    'label' => __( 'Clients', BUNCH_NAME ),
                    'name' => 'clients',
                    'description' => __( 'This section is used to add Clients.', BUNCH_NAME ),
                    'fields' => array(
                         array(
                             'type' => 'textbox',
                            'name' => 'title',
                            'label' => __( 'Title', BUNCH_NAME ),
                            'description' => __( 'Enter the title of the client.', BUNCH_NAME ), 
                        ),
						 array(
                             'type' => 'textbox',
                            'name' => 'client_link',
                            'label' => __( 'Link', BUNCH_NAME ),
                            'description' => __( 'Enter the Link for client.', BUNCH_NAME ),
                            'default' => '#'
                        ),
                        array(
                            'type' => 'upload',
                            'name' => 'client_img',
                            'label' => __( 'Logo', BUNCH_NAME ),
                            'description' => __( 'choose the brand logo.', BUNCH_NAME ),
                            'default' => '',
							
                         ),  
                    ) 
                ) 
            ) 
        ), */
		 // Pages , Blog Pages Settings
         array(
            'title' => __( 'Page Settings', BUNCH_NAME ),
            'name' => 'page_settings',
            'icon' => 'font-awesome:fa fa-file',
            'menus' => array(
                // Search Page Settings 
                array(
                    'title' => __( 'Search Page', BUNCH_NAME ),
                    'name' => 'search_page_settings',
                    'icon' => 'font-awesome:fa fa-search',
                    'controls' => array(
                        array(
                            'type' => 'textbox',
                            'name' => 'search_page_header_title',
                            'label' => __( 'Title', BUNCH_NAME ),
                            'description' => __( 'Enter Search Page Title.', BUNCH_NAME ),
                            'default' => '',
							
                        ),
						array(
                            'type' => 'upload',
                            'name' => 'search_page_header_img',
                            'label' => __( 'Header image', BUNCH_NAME ),
                            'description' => __( 'Enter Search Page Header Image.', BUNCH_NAME ),
                            'default' => '',
							
                        ),
						array(
                             'type' => 'select',
                            'name' => 'search_page_sidebar',
                            'label' => __( 'Sidebar', BUNCH_NAME ),
                            'items' => array(
                                 'data' => array(
                                     array(
                                         'source' => 'function',
                                        'value' => 'bunch_get_sidebars_2' 
                                    ) 
                                ) 
                            ),
                            'default' => array(
                                 '{{first}}' 
                            ) 
                        ),
                        array(
                             'type' => 'radioimage',
                            'name' => 'search_page_layout',
                            'label' => __( 'Page Layout', BUNCH_NAME ),
                            'description' => __( 'Choose The Layout for Search Page.', BUNCH_NAME ),
                            
                            'items' => array(
                                 array(
                                    'value' => 'left',
                                    'label' => __( 'Left Sidebar', BUNCH_NAME ),
                                    'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cl.png' 
                                ),
                                
                                array(
                                    'value' => 'right',
                                    'label' => __( 'Right Sidebar', BUNCH_NAME ),
                                    'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cr.png' 
                                ),
                                array(
                                    'value' => 'full',
                                    'label' => __( 'Full Width', BUNCH_NAME ),
                                    'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/1col.png' 
                                ),
                                
                            ) 
                        ),
                    ) 
                ),
                // Archive Page Settings 
                array(
                    'title' => __( 'Archive Page', BUNCH_NAME ),
                    'name' => 'archive_page_settings',
                    'icon' => 'font-awesome:fa fa-archive',
                    'controls' => array(
                        array(
                            'type' => 'textbox',
                            'name' => 'archive_page_header_title',
                            'label' => __( 'Title', BUNCH_NAME ),
                            'description' => __( 'Enter Archive Page Title.', BUNCH_NAME ),
                            'default' => '',
							
                        ),
						array(
                            'type' => 'upload',
                            'name' => 'archive_page_header_img',
                            'label' => __( 'Header Image', BUNCH_NAME ),
                            'description' => __( 'Enter Archive Page Header Image', BUNCH_NAME ),
                            'default' => '',
							
                        ),
					    array(
                             'type' => 'select',
                            'name' => 'archive_page_sidebar',
                            'label' => __( 'Sidebar', BUNCH_NAME ),
                            'items' => array(
                                 'data' => array(
                                     array(
                                         'source' => 'function',
                                        'value' => 'bunch_get_sidebars_2' 
                                    ) 
                                ) 
                            ),
                            'default' => array(
                                 '{{first}}' 
                            ) 
                        ),
                        array(
                             'type' => 'radioimage',
                            'name' => 'archive_page_layout',
                            'label' => __( 'Page Layout', BUNCH_NAME ),
                            'description' => __( 'Choose The Layout for Archive Page.', BUNCH_NAME ),
                            
                            'items' => array(
                                 array(
                                    'value' => 'left',
                                    'label' => __( 'Left Sidebar', BUNCH_NAME ),
                                    'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cl.png' 
                                ),
                                array(
                                    'value' => 'right',
                                    'label' => __( 'Right Sidebar', BUNCH_NAME ),
                                    'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cr.png' 
                                ),
                                array(
                                    'value' => 'full',
                                    'label' => __( 'Full Width', BUNCH_NAME ),
                                    'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/1col.png' 
                                ), 
                                
                            ) 
                        ) 
                        
                        
                    ) 
                ),
                // Author Page Settings 
                array(
                     'title' => __( 'Author Page', BUNCH_NAME ),
                    'name' => 'author_page_settings',
                    'icon' => 'font-awesome:fa fa-user',
                    'controls' => array(
                        array(
                            'type' => 'textbox',
                            'name' => 'author_page_header_title',
                            'label' => __( 'Title', BUNCH_NAME ),
                            'description' => __( 'Enter Author Page Title.', BUNCH_NAME ),
                            'default' => '',
							
                        ),
						array(
                            'type' => 'upload',
                            'name' => 'author_page_header_img',
                            'label' => __( 'Header Image', BUNCH_NAME ),
                            'description' => __( 'Enter Author Page Header Image', BUNCH_NAME ),
                            'default' => '',
						),
						array(
                             'type' => 'select',
                            'name' => 'author_page_sidebar',
                            'label' => __( 'Sidebar', BUNCH_NAME ),
                            'items' => array(
                                 'data' => array(
                                     array(
                                         'source' => 'function',
                                        'value' => 'bunch_get_sidebars_2' 
                                    ) 
                                ) 
                            ),
                            'default' => array(
                                 '{{first}}' 
                            ) 
                        ),
                        array(
                             'type' => 'radioimage',
                            'name' => 'author_page_layout',
                            'label' => __( 'Page Layout', BUNCH_NAME ),
                            'description' => __( 'Choose The Layout for Author Page.', BUNCH_NAME ),
                            
                            'items' => array(
                                 array(
                                     'value' => 'left',
                                    'label' => __( 'Left Sidebar', BUNCH_NAME ),
                                    'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cl.png' 
                                ),
                                
                                array(
                                     'value' => 'right',
                                    'label' => __( 'Right Sidebar', BUNCH_NAME ),
                                    'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cr.png' 
                                ),
                                array(
                                     'value' => 'full',
                                    'label' => __( 'Full Width', BUNCH_NAME ),
                                    'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/1col.png' 
                                ),
                                
                            ) 
                        ) 
                        
                    ) 
                ),
                // 404 Page Settings 
                array(
                    'title' => __( '404 Page Settings', BUNCH_NAME ),
                    'name' => '404_page_settings',
                    'icon' => 'font-awesome:fa fa-exclamation-triangle',
                    'controls' => array(
                         array(
                             'type' => 'textbox',
                            'name' => '404_page_title',
                            'label' => __( 'Page Title', BUNCH_NAME ),
                            'description' => __( 'Enter 404 Error Page Title.', BUNCH_NAME ),
                            'default' => '404' 
                        ),
                        array(
                             'type' => 'textbox',
                            'name' => '404_page_heading',
                            'label' => __( 'Page Heading', BUNCH_NAME ),
                            'description' => __( 'Enter the Heading you want to show on 404 page', BUNCH_NAME ),
                            'default' => 'Oops! That page can’t be found' 
                        ),
                        array(
                             'type' => 'textarea',
                            'name' => '404_page_text',
                            'label' => __( '404 Page Text', BUNCH_NAME ),
                            'description' => __( 'Enter the Text you want to show on 404 page', BUNCH_NAME ),
                            'default' => 'Sorry, but the page you are looking for does not existing' 
                        ),
                        array(
                             'type' => 'upload',
                            'name' => '404_page_bg',
                            'label' => __( 'Background  Image', BUNCH_NAME ),
                            'description' => __( 'Upload Image for 404 Page Background', BUNCH_NAME ),
                            'default' => get_template_directory_uri() . '/images/background/4.jpg' 
                        ),
                        array(
                             'type' => 'textbox',
                            'name' =>  '404_button_title',
                            'label' => __( 'Button Title', BUNCH_NAME ),
                            'description' => __( 'Enter the Button Title', BUNCH_NAME ),
                            'default' => 'Go To Home Page' 
                        ),
                    ) 
                ),
                // Comming Soon Page Settings 
                array(
                    'title' => __( 'Comming Soon Page Settings', BUNCH_NAME ),
                    'name' => 'comming_soon_page_settings',
                    'icon' => 'font-awesome:fa fa-exclamation-triangle',
                    'controls' => array(
                        array(
                            'type' => 'upload',
                            'name' => 'cs_section_img',
                            'label' => __( 'Page Background Image', BUNCH_NAME ),
                            'description' => __( 'Upload Image for Comming Soon Page Background', BUNCH_NAME ),
                            'default' => get_template_directory_uri() . '/images/background/6.jpg' 
                        ),
                        array(
                             'type' => 'textbox',
                            'name' => 'cs_section_title',
                            'label' => __( 'Page Heading', BUNCH_NAME ),
                            'description' => __( 'Enter the Heading you want to show on Comming Soon page', BUNCH_NAME ),
                            'default' => 'We are Coming Soon...' 
                        ),
                        array(
                             'type' => 'textbox',
                            'name' => 'cs_section_count',
                            'label' => __( 'Page Counter ', BUNCH_NAME ),
                            'description' => __( 'Enter the Counter you want to show on Comming Soon page', BUNCH_NAME ),
                            'default' => '2018/8/17' 
                        ),
                        array(
                             'type' => 'textarea',
                            'name' => 'cs_section_text',
                            'label' => __( 'Comming Soon Page Description', BUNCH_NAME ),
                            'description' => __( 'Enter the Text you want to show on Comming Soon page', BUNCH_NAME ),
                            'default' => 'Website is under construction. We will be here soon with new <br> awesome site, Subscribe to be notified.' 
                        ),
                        array(
                             'type' => 'textbox',
                            'name' => 'cs_id',
                            'label' => __( 'Feedburner id ', BUNCH_NAME ),
                            'description' => __( 'Enter the Feedburner id', BUNCH_NAME ),
                            'default' => 'themeforest' 
                        ),
                    ) 
                )
            ) 
        ),
		 // Woocommerce Page Settings 
		 array(
			'title' => __( 'Woocommerce', BUNCH_NAME ),
			'name' => 'woocommerce_page_settings',
			'icon' => 'font-awesome:fa fa-shopping-cart',
			'controls' => array(
				array(
					'type' => 'textbox',
					'name' => 'woocommerce_page_header_title',
					'label' => __( 'Title', BUNCH_NAME ),
					'description' => __( 'Enter Woocommerce general Page Title .', BUNCH_NAME ),
					'default' => '',
				),
				array(
					'type' => 'upload',
					'name' => 'woocommerce_page_header_img',
					'label' => __( 'Header image', BUNCH_NAME ),
					'description' => __( 'Enter woocommerce general Page Header image .', BUNCH_NAME ),
					'default' => '',
				),
				// product cat settings
				array(
					'type' => 'section',
					'repeating' => true,
					'sortable' => true,
					'title' => __( 'Product Category Page', BUNCH_NAME ),
					'name' => 'product_category_page',
					'description' => __( 'This section is used for Product Category Page settings', BUNCH_NAME ),
					'fields' => array(
						array(
							'type' => 'select',
							'name' => 'woocommerce_cat_page_sidebar',
							'label' => __( 'Sidebar', BUNCH_NAME ),
							'items' => array(
								 'data' => array(
									 array(
										 'source' => 'function',
										'value' => 'bunch_get_sidebars_2' 
									) 
								) 
							),
							'default' => array(
								 '{{first}}' 
							) 
						),
						array(
							 'type' => 'radioimage',
							'name' => 'woo_cat_page_layout',
							'label' => __( 'Woocommerce Category Layout', BUNCH_NAME ),
							'description' => __( 'Choose the layout for Category pages', BUNCH_NAME ),
							
							'items' => array(
								 array(
									 'value' => 'left',
									'label' => __( 'Left Sidebar', BUNCH_NAME ),
									'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cl.png', 
								),
								
								array(
									 'value' => 'right',
									'label' => __( 'Right Sidebar', BUNCH_NAME ),
									'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cr.png', 
								),
								array(
									 'value' => 'full',
									'label' => __( 'Full Width', BUNCH_NAME ),
									'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/1col.png', 
								),
								
							) 
						),
					)
				),
				//product single settings
				array(
					'type' => 'section',
					'repeating' => true,
					'sortable' => true,
					'title' => __( 'Product Single Page', BUNCH_NAME ),
					'name' => 'product_single_page',
					'description' => __( 'This section is used for Product Single Page general settings', BUNCH_NAME ),
					'fields' => array(
						array(
							'type' => 'select',
							'name' => 'woocommerce_single_page_sidebar',
							'label' => __( 'Sidebar', BUNCH_NAME ),
							'items' => array(
								 'data' => array(
									 array(
										 'source' => 'function',
										'value' => 'bunch_get_sidebars_2' 
									) 
								) 
							),
							'default' => array(
								 '{{first}}' 
							) 
						),
						array(
							'type' => 'radioimage',
							'name' => 'woocommerce_single_page_layout',
							'label' => __( 'Woocommerce Single Product Layout', BUNCH_NAME ),
							'description' => __( 'Choose the layout for Single pages', BUNCH_NAME ),
							
							'items' => array(
								 array(
									 'value' => 'left',
									'label' => __( 'Left Sidebar', BUNCH_NAME ),
									'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cl.png', 
								),
								
								array(
									 'value' => 'right',
									'label' => __( 'Right Sidebar', BUNCH_NAME ),
									'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cr.png', 
								),
								array(
									 'value' => 'full',
									'label' => __( 'Full Width', BUNCH_NAME ),
									'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/1col.png', 
								),
								
							) 
						),
					)
				),
				//woocommerce other settings
				array(
					'type' => 'section',
					'repeating' => true,
					'sortable' => true,
					'title' => __( 'Woocommerce Other Settings', BUNCH_NAME ),
					'name' => 'woocommerce_other_settings',
					'description' => __( 'This section is used for Woocommerce Other general settings', BUNCH_NAME ),
					'fields' => array(
						array(
                            'type' => 'toggle',
                            'name' => 'product_ordering',
                            'label' => __( 'Product Ordering', BUNCH_NAME ),
							'default' => 0,
							'description' => __('show or hide Product Ordering on Shop Page.', BUNCH_NAME)
						),
						array(
							'type' => 'textbox',
							'name' => 'number_of_products_per_page',
							'label' => __( 'Number of Products Per Page', BUNCH_NAME ),
							'description' => __( 'Enter number .', BUNCH_NAME ),
							'default' => '',
						),
						array(
						   'type' => 'select',
						   'name' => 'number_of_product_column',
						   'label' => __( 'Product Columns', BUNCH_NAME ),
						   'items' => array(
									 array(
									 'value' => '2',
									 'label' => __( '2', BUNCH_NAME ),
									),
									array(
									 'value' => '3',
									 'label' => __( '3', BUNCH_NAME ),
									),
									array(
									 'value' => '4',
									 'label' => __( '4', BUNCH_NAME ),
									),
							   ),
							   'default' => '3'
						),
						array(
						   'type' => 'select',
						   'name' => 'number_of_related_products',
						   'label' => __( 'Number Of Related Products', BUNCH_NAME ),
						   'items' => array(
									 array(
									 'value' => '2',
									 'label' => __( '2', BUNCH_NAME ),
									),
									array(
									 'value' => '3',
									 'label' => __( '3', BUNCH_NAME ),
									),
									array(
									 'value' => '4',
									 'label' => __( '4', BUNCH_NAME ),
									),
							   ),
							   'default' => '3'
						  ),
					)
				),
			) 
		),
		 // Social Sharing
         array(
            'title' => __( 'Social Sharing ', BUNCH_NAME ),
            'name' => 'social_sharing',
            'icon' => 'font-awesome:fa fa-share-alt',
            'controls' => array(
                 	array(
						'type' => 'toggle',
						'name' => 'facebook_sharing',
						'label' => __( 'Facebook', BUNCH_NAME ),
						'default' => 0,
						'description' => __('show or hide Facebook on blog pages', BUNCH_NAME)
					),
					array(
						'type' => 'toggle',
						'name' => 'twitter_sharing',
						'label' => __( 'Twitter', BUNCH_NAME ),
						'default' => 0,
						'description' => __('show or hide Twitter on blog pages', BUNCH_NAME)
					),
					array(
						'type' => 'toggle',
						'name' => 'linkedin_sharing',
						'label' => __( 'LinkedIn', BUNCH_NAME ),
						'default' => 0,
						'description' => __('show or hide LinkedIn on blog pages', BUNCH_NAME)
					),
					array(
						'type' => 'toggle',
						'name' => 'pinterest_sharing',
						'label' => __( 'Pinterest', BUNCH_NAME ),
						'default' => 0,
						'description' => __('show or hide Pinterest on blog pages', BUNCH_NAME)
					),
					array(
						'type' => 'toggle',
						'name' => 'google_plus_sharing',
						'label' => __( 'Google Plus', BUNCH_NAME ),
						'default' => 0,
						'description' => __('show or hide Google Plus on blog pages', BUNCH_NAME)
					),
					array(
						'type' => 'toggle',
						'name' => 'tumblr_sharing',
						'label' => __( 'Tumblr', BUNCH_NAME ),
						'default' => 0,
						'description' => __('show or hide Tumblr on blog pages', BUNCH_NAME)
					),
					array(
						'type' => 'toggle',
						'name' => 'reddit_sharing',
						'label' => __( 'Reddit', BUNCH_NAME ),
						'default' => 0,
						'description' => __('show or hide Reddit on blog pages', BUNCH_NAME)
					),
					array(
						'type' => 'toggle',
						'name' => 'digg_sharing',
						'label' => __( 'Digg', BUNCH_NAME ),
						'default' => 0,
						'description' => __('show or hide Digg on blog pages', BUNCH_NAME)
					), 
             ) 
         ),
         // Sidebar Creator
         array(
            'title' => __( 'Sidebar Settings', BUNCH_NAME ),
            'name' => 'sidebar-settings',
            'icon' => 'font-awesome:fa fa-bars',
            'controls' => array(
                 array(
                    'type' => 'builder',
                    'repeating' => true,
                    'sortable' => true,
                    'label' => __( 'Dynamic Sidebar', BUNCH_NAME ),
                    'name' => 'dynamic_sidebar',
                    'description' => __( 'This section is used for theme color settings', BUNCH_NAME ),
                    'fields' => array(
                         array(
                             'type' => 'textbox',
                            'name' => 'sidebar_name',
                            'label' => __( 'Sidebar Name', BUNCH_NAME ),
                            'description' => __( 'Choose the default color scheme for the theme.', BUNCH_NAME ),
                            'default' => __( 'Dynamic Sidebar', BUNCH_NAME ) 
                        ) 
                    ) 
                ) 
            ) 
        ),
         // Social Media Creator
         array(
            'title' => __( 'Social Media ', BUNCH_NAME ),
            'name' => 'social_media',
            'icon' => 'font-awesome:fa fa-share-square',
            'controls' => array(
                 array(
                     'type' => 'builder',
                    'repeating' => true,
                    'sortable' => true,
                    'label' => __( 'Social Media', BUNCH_NAME ),
                    'name' => 'social_media',
                    'description' => __( 'This section is used to add Social Media.', BUNCH_NAME ),
                    'fields' => array(
                         array(
                             'type' => 'textbox',
                            'name' => 'title',
                            'label' => __( 'Title', BUNCH_NAME ),
                            'description' => __( 'Enter the title of the social media.', BUNCH_NAME ), 
                        ),
						 array(
                             'type' => 'textbox',
                            'name' => 'social_link',
                            'label' => __( 'Link', BUNCH_NAME ),
                            'description' => __( 'Enter the Link for Social Media.', BUNCH_NAME ),
                            'default' => '#'
                        ),
                        array(
                            'type' => 'select',
                            'name' => 'social_icon',
                            'label' => __( 'Icon', BUNCH_NAME ),
                            'description' => __( 'Choose Icon for Social Media.', BUNCH_NAME ),
							'items' => array(
								'data' => array(
									array(
										'source' => 'function',
										'value' => 'vp_get_social_medias',
									),
								),
							),
                        )  
                    ) 
                ) 
            ) 
         ),
         // Font settings
         array(
            'title' => __( 'Font Settings', BUNCH_NAME ),
            'name' => 'font_settings',
            'icon' => 'font-awesome:fa fa-font',
            'menus' => array(
                /** heading font settings */
                 array(
                    'title' => __( 'Heading Font', BUNCH_NAME ),
                    'name' => 'heading_font_settings',
                    'icon' => 'font-awesome:fa fa-text-height',
                    'controls' => array(
                         array(
                             'type' => 'toggle',
                            'name' => 'use_custom_font',
                            'label' => __( 'Use Custom Font', BUNCH_NAME ),
                            'description' => __( 'Use custom font or not', BUNCH_NAME ),
                            'default' => 0 
                         ),
                         array(
                            'type' => 'section',
                            'title' => __( 'H1 Settings', BUNCH_NAME ),
                            'name' => 'h1_settings',
                            'description' => __( 'heading 1 font settings', BUNCH_NAME ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', BUNCH_NAME ),
                                    'name' => 'h1_font_family',
                                    'description' => __( 'Select the font family to use for h1', BUNCH_NAME ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                
                                array(
                                     'type' => 'color',
                                    'name' => 'h1_font_color',
                                    'label' => __( 'Font Color', BUNCH_NAME ),
                                    'description' => __( 'Choose the font color for heading h1', BUNCH_NAME ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                         ),
                         array(
                             'type' => 'section',
                            'title' => __( 'H2 Settings', BUNCH_NAME ),
                            'name' => 'h2_settings',
                            'description' => __( 'heading h2 font settings', BUNCH_NAME ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', BUNCH_NAME ),
                                    'name' => 'h2_font_family',
                                    'description' => __( 'Select the font family to use for h2', BUNCH_NAME ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                ),
                                array(
                                     'type' => 'color',
                                    'name' => 'h2_font_color',
                                    'label' => __( 'Font Color', BUNCH_NAME ),
                                    'description' => __( 'Choose the font color for heading h1', BUNCH_NAME ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                         ),
                         array(
                             'type' => 'section',
                            'title' => __( 'H3 Settings', BUNCH_NAME ),
                            'name' => 'h3_settings',
                            'description' => __( 'heading h3 font settings', BUNCH_NAME ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', BUNCH_NAME ),
                                    'name' => 'h3_font_family',
                                    'description' => __( 'Select the font family to use for h3', BUNCH_NAME ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                array(
                                     'type' => 'color',
                                    'name' => 'h3_font_color',
                                    'label' => __( 'Font Color', BUNCH_NAME ),
                                    'description' => __( 'Choose the font color for heading h3', BUNCH_NAME ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                         ),
                         array(
                            'type' => 'section',
                            'title' => __( 'H4 Settings', BUNCH_NAME ),
                            'name' => 'h4_settings',
                            'description' => __( 'heading h4 font settings', BUNCH_NAME ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', BUNCH_NAME ),
                                    'name' => 'h4_font_family',
                                    'description' => __( 'Select the font family to use for h4', BUNCH_NAME ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                array(
                                     'type' => 'color',
                                    'name' => 'h4_font_color',
                                    'label' => __( 'Font Color', BUNCH_NAME ),
                                    'description' => __( 'Choose the font color for heading h4', BUNCH_NAME ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                        ),
                        
                        array(
                             'type' => 'section',
                            'title' => __( 'H5 Settings', BUNCH_NAME ),
                            'name' => 'h5_settings',
                            'description' => __( 'heading h5 font settings', BUNCH_NAME ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', BUNCH_NAME ),
                                    'name' => 'h5_font_family',
                                    'description' => __( 'Select the font family to use for h5', BUNCH_NAME ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                array(
                                     'type' => 'color',
                                    'name' => 'h5_font_color',
                                    'label' => __( 'Font Color', BUNCH_NAME ),
                                    'description' => __( 'Choose the font color for heading h5', BUNCH_NAME ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                        ),
                        
                        array(
                             'type' => 'section',
                            'title' => __( 'H6 Settings', BUNCH_NAME ),
                            'name' => 'h6_settings',
                            'description' => __( 'heading h6 font settings', BUNCH_NAME ),
                            'dependency' => array(
                                 'field' => 'use_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', BUNCH_NAME ),
                                    'name' => 'h6_font_family',
                                    'description' => __( 'Select the font family to use for h6', BUNCH_NAME ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                array(
                                     'type' => 'color',
                                    'name' => 'h6_font_color',
                                    'label' => __( 'Font Color', BUNCH_NAME ),
                                    'description' => __( 'Choose the font color for heading h6', BUNCH_NAME ),
                                    'default' => '#98ed28' 
                                ) 
                            ) 
                        ) 
                    ) 
                ),
                
                /** body font settings */
                array(
                     'title' => __( 'Body Font', BUNCH_NAME ),
                    'name' => 'body_font_settings',
                    'icon' => 'font-awesome:fa fa-text-width',
                    'controls' => array(
                         array(
                             'type' => 'toggle',
                            'name' => 'body_custom_font',
                            'label' => __( 'Use Custom Font', BUNCH_NAME ),
                            'description' => __( 'Use custom font or not', BUNCH_NAME ),
                            'default' => 0 
                        ),
                        array(
                             'type' => 'section',
                            'title' => __( 'Body Font Settings', BUNCH_NAME ),
                            'name' => 'body_font_settings1',
                            'description' => __( 'body font settings', BUNCH_NAME ),
                            'dependency' => array(
                                 'field' => 'body_custom_font',
                                'function' => 'vp_dep_boolean' 
                            ),
                            'fields' => array(
                                
                                 array(
                                     'type' => 'select',
                                    'label' => __( 'Font Family', BUNCH_NAME ),
                                    'name' => 'body_font_family',
                                    'description' => __( 'Select the font family to use for body', BUNCH_NAME ),
                                    'items' => array(
                                         'data' => array(
                                             array(
                                                 'source' => 'function',
                                                'value' => 'vp_get_gwf_family' 
                                            ) 
                                        ) 
                                    ) 
                                    
                                ),
                                
                                array(
                                     'type' => 'color',
                                    'name' => 'body_font_color',
                                    'label' => __( 'Font Color', BUNCH_NAME ),
                                    'description' => __( 'Choose the font color for heading body', BUNCH_NAME ),
                                    'default' => '#686868' 
                                ) 
                            ) 
                        ) 
                    ) 
                ) 
            ) 
        ), 
	) 
);
/**
 *EOF
 */