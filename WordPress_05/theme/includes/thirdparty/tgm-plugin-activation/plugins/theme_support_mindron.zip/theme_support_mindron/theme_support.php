<?php
/*
Plugin Name: Theme Support
Plugin URI: http://themeforest.net/
Description: This plugin is compatible with this wordpress themes. 
Author: Muhibbur Rashid
Author URI: http://themebunch.com
Version: 1.0
Text Domain: BUNCH_NAME
*/
if( !defined( 'BUNCH_TH_ROOT' ) ) define('BUNCH_TH_ROOT', plugin_dir_path( __FILE__ ));
if( !defined( 'BUNCH_TH_URL' ) ) define( 'BUNCH_TH_URL', plugins_url( '', __FILE__ ) );
if( !defined( 'BUNCH_NAME' ) ) define( 'BUNCH_NAME', 'mindron' );
include_once( 'includes/loader.php' );
function mindron_bunch_widget_init2()
{
	global $wp_registered_sidebars;
	$theme_options = _WSH()->option();
	if( class_exists( 'Bunch_About_us' ) )register_widget( 'Bunch_About_us' );
	if( class_exists( 'Bunch_servies' ) )register_widget( 'Bunch_servies' );
	if( class_exists( 'Bunch_Get_in_Touch' ) )register_widget( 'Bunch_Get_in_Touch' );
	if( class_exists( 'Bunch_Single_servies' ) )register_widget( 'Bunch_Single_servies' );
	if( class_exists( 'Bunch_Brochures' ) )register_widget( 'Bunch_Brochures' );
    if( class_exists( 'Bunch_Single_Info' ) )register_widget( 'Bunch_Single_Info' );
    if( class_exists( 'Bunch_Recent_News' ) )register_widget( 'Bunch_Recent_News' );
}
add_action( 'widgets_init', 'mindron_bunch_widget_init2' );